package com.example.homeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
