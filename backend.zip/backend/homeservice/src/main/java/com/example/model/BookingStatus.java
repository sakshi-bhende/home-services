package com.example.model;

public enum BookingStatus {
    PENDING, ACCEPTED, REJECTED, CANCELLED, COMPLETED
}
