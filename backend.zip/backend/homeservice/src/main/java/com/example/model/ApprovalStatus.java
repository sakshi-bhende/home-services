package com.example.model;

public enum ApprovalStatus {
	UNAPPROVED,
	APPROVED,
	PENDING,
	REJECTED
}
