package com.example.model;

public enum DisputeStatus {
	PENDING,
	RESOLVED,
	ESCALATED,
	UNDER_REVIEW
}
