package com.example.model;

public enum Availability {
	AVAILABLE, 
	UNAVAILABLE
}
